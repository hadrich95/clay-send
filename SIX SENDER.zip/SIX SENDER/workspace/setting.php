<?php

/*
   ╔╦╗╦╔═╗╔═╗  ╔═╗╔═╗╔╦╗╦ ╦╔═╗
    ║ ║╠═╝╚═╗  ╚═╗║╣  ║ ║ ║╠═╝
    ╩ ╩╩  ╚═╝  ╚═╝╚═╝ ╩ ╚═╝╩
────────────────────────────────
* Use of other tools already provided by owner SIX. If you have some problem.

* You can contact the manufacturer of the SIX support if you need help or find some error in sender SIX 1.3.1.

* If You Want to Contact The SIX Provider You Can Via Contact Below
  FB       : https://www.facebook.com/vidz.sianipar (Vidz)
  Whatsapp : +6282370721424
$regards = "

* Use wisely. We are not responsible for the GX40 hacking. Because we provide the CLAY As Sender Email basically.

date_default_timezone_set('Asia/Jakarta');
$date = date('F d, Y, h:i A T');



███████╗██╗██╗  ██╗         ██╗   ██╗       ██╗   ██████╗    ██╗
██╔════╝██║╚██╗██╔╝         ██║   ██║      ███║   ╚════██╗  ███║
███████╗██║ ╚███╔╝          ██║   ██║█████╗╚██║    █████╔╝  ╚██║
╚════██║██║ ██╔██╗          ╚██╗ ██╔╝╚════╝ ██║    ╚═══██╗   ██║
███████║██║██╔╝ ██╗          ╚████╔╝        ██║██╗██████╔╝██╗██║
╚══════╝╚═╝╚═╝  ╚═╝           ╚═══╝         ╚═╝╚═╝╚═════╝ ╚═╝╚═╝



";

/*


	Setting your fucking needs here!!

    Fiture :

    * Random From Mail with List in script.
    * Random From Name with List in script.
    * Random Subject with List in script.
    * Random Character.
    * Random Number.
    (+) Tag Replace Email, Tag Random Subject, etc. Use this in ur letter

     		##email## : replace the contents of the letter to show the recipient's email
     		##subject## : Using random subject
     		##frommail## : Using random From mail
     		##fromname## : Using random From name
     		##short## : Using random your URL
     		##country## : Using random country around the world
     		##date## : Using date time. (NOT RANDOM)
    		##OS## : Using random Operating Systems
    		##browser## : Using random Browsers
    		##randomip## : Using randomg IP
    (+ NOte ) Learning Toolkit Using Latter SIX - Learning.html (letter/SIX - Learning.html)
*/

	/*	Pengaturan smtpserver 	*/

		$smtpserver = "smtp-relay.gmail.com";	// Required

	$smtpuser = "apple2@help-verify-id.com";		// Required

	$smtppass = "buyer123";		// Required

	$smtpport = "587";		// Required

	$priority = 1; 		// 1 = High Priority. 0 = Normal Priority

 		# code...
	/*	end 	*/



	/*		Random Fiture	*/

	$userandom = 0;		//	1 untuk menggunakan, 0 untuk tidak
	$sleeptime = 3;		//	Waktu jeda tiap mail. Default 3

	/*	End 	*/



	/*		Setting your f*cking list	*/

	$mailist = "MAILIST/LIST.txt";		//	Isi nama file mailist kamu

	/*	End 	*/


	/*	Pengaturan mail 	*/

	$fromname = "Apple Support";		// Kosongkan jika menggunakan random fiture

	$frommail ="##randstring##.noreply-unlocked##randstring##@##randstring##.apple-servicerecover.com";		// Kosongkan jika menggunakan random fiture
	$subject = "RE: [New Statement] Wee been detected your Apple Account sign-in New Browser,on 8/11/2018 [FWD]";		// Kosongkan jika menggunakan random fiture

	$msgfile = "LETTER/SIX.html";		//Letter harus mengikuti rule SIX - MIX.html

	$replacement = 1;	//	Untuk mengaktifkan function replace. 1 untuk menggunakan, 0 untuk tidak.

	/*	End 	*/


	/*	Rand url 	*/
    /* For Using Multi (Random Directlink)*/
	/* $randurl = array("http://google.com","http://bing.com");
    /* For Using single Directlink */
    $randurl = array("http://ow.lys2t730LuDQt");
//	Kosongkan jika tidak menggunakan


    /*	End 	*/


    /* Menghapus email yang telah di eksekusi    */

    $userremoveline = 0;		//

    /* End */